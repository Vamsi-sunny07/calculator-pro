const expressionEl = document.getElementById("expression");
const resultEl = document.getElementById("result");
const statusEl = document.getElementById("statusLabel");
const angleButton = document.getElementById("angleMode");
const modeLabel = document.getElementById("modeLabel");
const historyList = document.getElementById("historyList");

let expression = "";
let angleMode = "DEG";
let memoryValue = 0;
let lastResult = 0;
let soundEnabled = false;
let audioContext = null;

function prettyExpression(value) {
    return value.replaceAll("*", "×").replaceAll("/", "÷");
}
function updateDisplay() {
    expressionEl.textContent = expression ? prettyExpression(expression) : "0";
    angleButton.textContent = angleMode;
    angleButton.dataset.mode = angleMode;
    modeLabel.textContent = angleMode === "DEG" ? "DEGREES" : "RADIANS";
}
function beep() {
    if (!soundEnabled) return;
    try {
        audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gain = audioContext.createGain();
        oscillator.connect(gain);
        gain.connect(audioContext.destination);
        oscillator.frequency.value = 620;
        gain.gain.setValueAtTime(0.035, audioContext.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.07);
        oscillator.start();
        oscillator.stop(audioContext.currentTime + 0.07);
    } catch (_) {}
}
function insert(value) {
    beep();
    expression += value;
    statusEl.textContent = "EDITING";
    updateDisplay();
}
function clearAll() {
    expression = "";
    resultEl.textContent = "0";
    statusEl.textContent = "READY";
    updateDisplay();
}
function deleteLast() {
    expression = expression.slice(0, -1);
    updateDisplay();
}
function replaceLastNumber(transform) {
    const match = expression.match(/(\d+(?:\.\d*)?|\.\d+)$/);
    if (!match) return;
    const start = match.index;
    expression = expression.slice(0, start) + transform(match[0]);
    updateDisplay();
}
function toggleSign() {
    replaceLastNumber(n => `(-${n})`);
}
function percentage() {
    replaceLastNumber(n => `(${n}/100)`);
}
function factorial() {
    replaceLastNumber(n => `factorial(${n})`);
}
function getDisplayedNumber() {
    const value = Number(resultEl.textContent);
    return Number.isFinite(value) ? value : lastResult;
}
async function calculate() {
    if (!expression.trim()) return;
    statusEl.textContent = "CALCULATING";
    try {
        const response = await fetch("/api/calculate", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({expression, angle_mode: angleMode})
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Calculation failed");
        resultEl.textContent = data.result;
        lastResult = Number(data.result);
        statusEl.textContent = "COMPLETE";
        await loadHistory();
    } catch (error) {
        resultEl.textContent = error.message;
        statusEl.textContent = "ERROR";
    }
}
async function loadHistory() {
    try {
        const response = await fetch("/api/history");
        const items = await response.json();
        historyList.replaceChildren();
        if (!items.length) {
            const empty = document.createElement("div");
            empty.className = "history-empty";
            empty.innerHTML = "<span>↗</span><strong>No calculations yet</strong><small>Your recent results will appear here.</small>";
            historyList.appendChild(empty);
            return;
        }
        items.forEach(item => {
            const card = document.createElement("div");
            card.className = "history-item";
            const exp = document.createElement("div");
            exp.className = "history-expression";
            exp.textContent = prettyExpression(item.expression);
            const res = document.createElement("div");
            res.className = "history-result";
            res.textContent = "= " + item.result;
            const time = document.createElement("div");
            time.className = "history-time";
            time.textContent = item.created_at;
            card.append(exp, res, time);
            card.addEventListener("click", () => {
                expression = item.expression;
                resultEl.textContent = item.result;
                lastResult = Number(item.result);
                updateDisplay();
                statusEl.textContent = "HISTORY LOADED";
            });
            historyList.appendChild(card);
        });
    } catch (_) {
        historyList.textContent = "Unable to load history.";
    }
}
async function clearHistory() {
    if (!confirm("Clear all saved calculations?")) return;
    await fetch("/api/history", {method: "DELETE"});
    await loadHistory();
}
function memoryAction(action) {
    if (action === "memory-clear") memoryValue = 0;
    if (action === "memory-recall") insert(String(memoryValue));
    if (action === "memory-add") memoryValue += getDisplayedNumber();
    if (action === "memory-subtract") memoryValue -= getDisplayedNumber();
    document.getElementById("memoryIndicator").style.opacity = memoryValue === 0 ? ".55" : "1";
}
document.querySelectorAll("[data-insert]").forEach(button => {
    button.addEventListener("click", () => insert(button.dataset.insert));
});
document.querySelectorAll("[data-action]").forEach(button => {
    button.addEventListener("click", () => {
        beep();
        const action = button.dataset.action;
        if (action === "clear") clearAll();
        else if (action === "delete") deleteLast();
        else if (action === "calculate") calculate();
        else if (action === "percent") percentage();
        else if (action === "sign") toggleSign();
        else if (action === "factorial") factorial();
        else if (action.startsWith("memory-")) memoryAction(action);
    });
});
angleButton.addEventListener("click", () => {
    angleMode = angleMode === "DEG" ? "RAD" : "DEG";
    updateDisplay();
});
document.getElementById("clearHistory").addEventListener("click", clearHistory);
document.getElementById("soundToggle").addEventListener("click", event => {
    soundEnabled = !soundEnabled;
    event.currentTarget.textContent = soundEnabled ? "♫" : "🔇";
    event.currentTarget.style.color = soundEnabled ? "#ff9f43" : "";
});
document.getElementById("themeToggle").addEventListener("click", () => {
    document.body.classList.toggle("light");
});
document.addEventListener("keydown", event => {
    if (/^[0-9.]$/.test(event.key)) insert(event.key);
    else if (["+", "-", "*", "/", "(", ")"].includes(event.key)) insert(event.key);
    else if (event.key === "Enter" || event.key === "=") {
        event.preventDefault();
        calculate();
    } else if (event.key === "Backspace") deleteLast();
    else if (event.key === "Escape") clearAll();
});
updateDisplay();
loadHistory();

import sqlite3
from pathlib import Path
from datetime import datetime

DB_PATH = Path(__file__).with_name("calculator.db")

def get_connection():
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection

def init_db():
    with get_connection() as connection:
        connection.execute("""
            CREATE TABLE IF NOT EXISTS calculation_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                expression TEXT NOT NULL,
                result TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)

def save_calculation(expression, result):
    with get_connection() as connection:
        connection.execute(
            "INSERT INTO calculation_history (expression, result, created_at) VALUES (?, ?, ?)",
            (expression, result, datetime.now().strftime("%d %b %Y, %I:%M %p"))
        )

def get_history(limit=30):
    with get_connection() as connection:
        rows = connection.execute(
            "SELECT id, expression, result, created_at FROM calculation_history ORDER BY id DESC LIMIT ?",
            (limit,)
        ).fetchall()
        return [dict(row) for row in rows]

def clear_history():
    with get_connection() as connection:
        connection.execute("DELETE FROM calculation_history")

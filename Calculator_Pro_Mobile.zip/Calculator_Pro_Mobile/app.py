from flask import Flask, render_template, request, jsonify
from database import init_db, save_calculation, get_history, clear_history
import ast
import math
import operator

app = Flask(__name__)
init_db()

BINARY_OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Pow: operator.pow,
    ast.Mod: operator.mod,
}
UNARY_OPERATORS = {ast.UAdd: operator.pos, ast.USub: operator.neg}

def evaluate_node(node, angle_mode="DEG"):
    if isinstance(node, ast.Expression):
        return evaluate_node(node.body, angle_mode)

    if isinstance(node, ast.Constant) and type(node.value) in (int, float):
        return node.value

    if isinstance(node, ast.BinOp) and type(node.op) in BINARY_OPERATORS:
        left = evaluate_node(node.left, angle_mode)
        right = evaluate_node(node.right, angle_mode)
        return BINARY_OPERATORS[type(node.op)](left, right)

    if isinstance(node, ast.UnaryOp) and type(node.op) in UNARY_OPERATORS:
        return UNARY_OPERATORS[type(node.op)](evaluate_node(node.operand, angle_mode))

    if isinstance(node, ast.Name):
        constants = {"pi": math.pi, "e": math.e}
        if node.id in constants:
            return constants[node.id]

    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and len(node.args) == 1:
        name = node.func.id
        value = evaluate_node(node.args[0], angle_mode)
        radians = math.radians(value) if angle_mode == "DEG" else value
        funcs = {
            "sqrt": math.sqrt,
            "sin": lambda x: math.sin(radians),
            "cos": lambda x: math.cos(radians),
            "tan": lambda x: math.tan(radians),
            "asin": lambda x: math.degrees(math.asin(x)) if angle_mode == "DEG" else math.asin(x),
            "acos": lambda x: math.degrees(math.acos(x)) if angle_mode == "DEG" else math.acos(x),
            "atan": lambda x: math.degrees(math.atan(x)) if angle_mode == "DEG" else math.atan(x),
            "log": math.log10,
            "ln": math.log,
            "abs": abs,
            "exp": math.exp,
            "factorial": lambda x: math.factorial(int(x)) if x >= 0 and float(x).is_integer() and x <= 170 else (_ for _ in ()).throw(ValueError("Factorial requires a whole number from 0 to 170")),
        }
        if name not in funcs:
            raise ValueError("Unsupported function")
        return funcs[name](value)

    raise ValueError("Invalid expression")

def calculate_expression(expression, angle_mode):
    if not isinstance(expression, str) or not expression.strip() or len(expression) > 250:
        raise ValueError("Enter a valid expression")
    if angle_mode not in ("DEG", "RAD"):
        raise ValueError("Invalid angle mode")
    try:
        tree = ast.parse(expression, mode="eval")
        result = evaluate_node(tree, angle_mode)
        if isinstance(result, complex) or not math.isfinite(float(result)):
            raise ValueError("Result is outside the supported range")
        return result
    except ZeroDivisionError:
        raise ValueError("Cannot divide by zero")
    except (SyntaxError, OverflowError):
        raise ValueError("Invalid or out-of-range calculation")
    except (ValueError, TypeError) as exc:
        raise ValueError(str(exc) or "Invalid calculation")

@app.route("/")
def home():
    return render_template("index.html")

@app.post("/api/calculate")
def calculate():
    data = request.get_json(silent=True) or {}
    expression = data.get("expression", "")
    angle_mode = data.get("angle_mode", "DEG")
    try:
        result = calculate_expression(expression, angle_mode)
        result_text = f"{result:.12g}" if isinstance(result, float) else str(result)
        save_calculation(expression, result_text)
        return jsonify({"result": result_text})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 400

@app.get("/api/history")
def history():
    return jsonify(get_history())

@app.delete("/api/history")
def delete_history():
    clear_history()
    return jsonify({"message": "History cleared"})

if __name__ == "__main__":
    app.run(debug=True)
